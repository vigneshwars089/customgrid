angular.module("myApp", ["ngTable", "ngTableDemos"]);

// (function() {
//   "use strict";
//
//   angular.module("myApp").controller("demoController", demoController);
//
//   demoController.$inject = ["NgTableParams", "ngTableGroupedList"];
//
//   function demoController(NgTableParams, simpleList) {
//     var self = this;
//     self.tableParams = new NgTableParams({}, {
//       dataset: simpleList
//     });
//   }
// })();

(function() {
  "use strict";

  angular.module("myApp").controller("dynamicDemoController", dynamicDemoController);
  dynamicDemoController.$inject = ["NgTableParams", "ngTableGroupedList"];

  function dynamicDemoController(NgTableParams, simpleList) {
    var self = this;
    // myList[i][columns[colIndex]];
    var Header = Object.keys(simpleList[0]);
    // self.cols = [
    //   { field: "name", title: "Name", show: true },
    //   { field: "age", title: "Age", show: true },
    //   { field: "money", title: "Money", show: true },
    //   { field: "country", title: "Country", show: true },
    // ];
    self.cols=[];
    for (var i = 0; i<Header.length; i++) {
      var m={field:Header[i],title:Header[i],show:true}
      self.cols.push(m);
    }
    console.log("change");
    // console.log(self.cols);
    self.tableParams = new NgTableParams({}, {
      dataset: simpleList
    });
    console.log(self);
  }
})();

(function() {
  "use strict";

  angular.module("myApp").run(configureDefaults);
  configureDefaults.$inject = ["ngTableDefaults"];

  function configureDefaults(ngTableDefaults) {
    ngTableDefaults.params.count = 15;
    ngTableDefaults.settings.counts = [];
  }
})();
